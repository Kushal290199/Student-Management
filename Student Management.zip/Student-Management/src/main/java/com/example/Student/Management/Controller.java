package com.example.Student.Management;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class Controller {
	
	@Autowired
	SessionFactory sf;

	// Insert data into table
	@PostMapping("insertRecord")
	public Student insert() {
		Session ss = sf.openSession();
		Transaction tx = ss.beginTransaction();

		Student s = new Student(101, "Kushal", "Computer", "A", 64.5f);
		ss.save(s);
		System.out.println(s);
		tx.commit();
		return s;
	}

	// Update data of table
	@PutMapping("updateRecord")
	public Student update() {
		Session ss = sf.openSession();
		Transaction tx = ss.beginTransaction();

		Student s = new Student(101, "Kushal", "Computer Engineering", "A", 70.4f);
		ss.update(s);
		System.out.println(s);
		tx.commit();
		return s;
	}

	// Delete specific data from table
	@DeleteMapping("deleteRecord")
	public Student delete() {
		Session ss = sf.openSession();
		Transaction tx = ss.beginTransaction();

		Student s = ss.get(Student.class, 101);
		ss.delete(s);
		System.out.println(s);
		tx.commit();
		return s;
	}

	// Retrieve data by Id
	@GetMapping("getASingleRecord")
	public Student getASingleRecord() {
		Session ss = sf.openSession();

		Student s = ss.get(Student.class, 101);
		return s;
	}

	// Retrieve all data from table
	@GetMapping("getMultipleRecord")
	public List<Student> getMultipleRecordDefault() {
		Session ss = sf.openSession();
		Query query = ss.createQuery("from Staff");
		List<Student> list = ((org.hibernate.query.Query) query).list();

		for (Student s : list) {
			System.out.println(s.getId() + " = = " + s.getName() + " " + s.getCourse() + " " + s.getDivision() + " "
					+ s.getMarks());
		}
		return list;
	}


}
